package com.smiligence.techAdmin.bean;

public class DeliveryFareDetails {
    int cartValue;
    int deliveryFare;
    String createdDate;

    public int getCartValue() {
        return cartValue;
    }

    public void setCartValue(int cartValue) {
        this.cartValue = cartValue;
    }

    public int getDeliveryFare() {
        return deliveryFare;
    }

    public void setDeliveryFare(int deliveryFare) {
        this.deliveryFare = deliveryFare;
    }

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }
}
