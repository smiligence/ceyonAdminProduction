package com.smiligence.techAdmin.bean;

public class PincodeDetails {
    String pinCode;

    public String getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(String createdDate) {
        this.createdDate = createdDate;
    }

    String createdDate;
    int pincodeId;

    public String getPincodeStatus() {
        return pincodeStatus;
    }

    public void setPincodeStatus(String pincodeStatus) {
        this.pincodeStatus = pincodeStatus;
    }

    String pincodeStatus;

    public int getPincodeId() {
        return pincodeId;
    }

    public void setPincodeId(int pincodeId) {
        this.pincodeId = pincodeId;
    }

    public String getPinCode() {
        return pinCode;
    }

    public void setPinCode(String pinCode) {
        this.pinCode = pinCode;
    }
}
