package com.smiligence.techAdmin.bean;

public class SuperCategoryDetails {
    String superCategoryId;
    String SuperCategoryName;

    public String getSuperCategoryCreatedDate() {
        return superCategoryCreatedDate;
    }

    public void setSuperCategoryCreatedDate(String superCategoryCreatedDate) {
        this.superCategoryCreatedDate = superCategoryCreatedDate;
    }

    String superCategoryCreatedDate;

    public String getSuperCategoryId() {
        return superCategoryId;
    }

    public void setSuperCategoryId(String superCategoryId) {
        this.superCategoryId = superCategoryId;
    }

    public String getSuperCategoryName() {
        return SuperCategoryName;
    }

    public void setSuperCategoryName(String superCategoryName) {
        SuperCategoryName = superCategoryName;
    }

    public String getSuperCategoryImage() {
        return superCategoryImage;
    }

    public void setSuperCategoryImage(String superCategoryImage) {
        this.superCategoryImage = superCategoryImage;
    }

    String superCategoryImage;
}
